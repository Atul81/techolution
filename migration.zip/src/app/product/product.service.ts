import { Injectable } from '@angular/core';
import { IProduct } from './product-interface';
import { Observable } from 'rxjs';
import { HttpClient } from '@angular/common/http';
import {map} from 'rxjs/operators';


@Injectable()
export class ProductService {
  private productUrl = './assets/api/products/products.json';

  constructor(private http: HttpClient) {
  }

  getProducts(): Observable<IProduct[]> {
    return this.http.get<IProduct[]>(this.productUrl);
  }

  getProduct(id: number): Observable<IProduct> {
    return this.getProducts()
      .pipe(map((products: IProduct[]) => products.find(p => p.productId === id)));
  }
}
